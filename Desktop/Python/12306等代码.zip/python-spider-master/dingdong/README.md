## 功能

下载京东商品的晒单图。

## 作者

* Website: [http://cuijiahua.com](http://cuijiahua.com "悬停显示")
* Author: Jack Cui
* Date: 2018.7.7

## 效果图：

![image](https://github.com/Jack-Cherish/Pictures/blob/master/jd.gif)

## 使用说明

	python jd.py -k 芒果

	三个参数：
	-d	保存图片的路径，默认为fd.py文件所在文件夹
	-k	搜索关键词
	-n  	下载商品的晒单图个数，即n个商店的晒单图
