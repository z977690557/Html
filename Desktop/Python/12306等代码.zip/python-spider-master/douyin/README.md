## 功能

下载指定用户的抖音视频。

## 作者

* Author: [Jack Cui](http://cuijiahua.com "悬停显示")、[steven7851](https://github.com/steven7851 "悬停显示")

## 运行效果

![image](https://github.com/Jack-Cherish/Pictures/blob/master/14.gif)

## 使用说明

	python douyin.py

关于重新链接次数: 用户视频通常重新链接30次以内会成功，而收藏视频目前链接成功机率极低，当然有耐心也能等他成功为止。。
